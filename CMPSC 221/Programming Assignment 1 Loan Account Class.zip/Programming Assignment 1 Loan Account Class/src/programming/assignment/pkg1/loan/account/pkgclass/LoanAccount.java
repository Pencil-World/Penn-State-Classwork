/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming.assignment.pkg1.loan.account.pkgclass;

/**
 *
 * @author iayfn
 */
public class LoanAccount {
    private static double annualInterestRate;
    private double principal;
    
    public LoanAccount(double _principal) {
        principal = _principal;
    }
    
    public double calculateMonthlyPayment(int numberOfPayments) {
        double monthlyInterest = annualInterestRate / 12;
        double monthlyPayment = principal * ( monthlyInterest / (1 - Math.pow(1 + monthlyInterest, -numberOfPayments)));
        return monthlyPayment;
    }
    
    public static void setAnnualInterestRate(int _annualInterestRate) {
        annualInterestRate = _annualInterestRate / 100.0;
    }
}
